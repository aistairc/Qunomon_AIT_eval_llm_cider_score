#! /bin/bash
pip3 install nltk==3.9.1
python -c "import nltk; nltk.download('punkt'); nltk.download('punkt_tab')"